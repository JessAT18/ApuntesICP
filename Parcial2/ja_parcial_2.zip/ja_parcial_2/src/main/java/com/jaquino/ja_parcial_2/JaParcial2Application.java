package com.jaquino.ja_parcial_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaParcial2Application {

	public static void main(String[] args) {
		SpringApplication.run(JaParcial2Application.class, args);
	}

}
