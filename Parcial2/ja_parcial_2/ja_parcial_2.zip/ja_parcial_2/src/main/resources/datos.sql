INSERT INTO vetbl_productos
    VALUES
        (1, "TABLET", 300, 400),
        (2, "DISCO DURO", 200, 300),
        (3, "TECLADO", 300, 400);