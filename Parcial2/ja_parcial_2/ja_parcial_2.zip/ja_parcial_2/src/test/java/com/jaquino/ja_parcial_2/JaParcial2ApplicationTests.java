package com.jaquino.ja_parcial_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaParcial2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
