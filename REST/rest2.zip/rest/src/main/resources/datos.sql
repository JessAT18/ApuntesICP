INSERT INTO vetbl_facturas
    VALUES
        (1, "TABLET", 300),
        (2, "DISCO DURO", 300);