package com.restapp.rest.restytest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/facturas")
public class FacturaController {
    @Autowired
    private FacturaRepository facturaRepository;

    @GetMapping
    public List<Factura> buscarTodas() {
        return facturaRepository.buscarTodas();
    }

    @GetMapping("/{numero}")
    public Factura buscarUnaFactura(@PathVariable int numero) { //@PathVariable("numero")
        return facturaRepository.buscarUnaFactura(numero);
    }

    @DeleteMapping("/{numero}")
    public void borrarUnaFactura(@PathVariable("numero") Factura factura) {
        facturaRepository.borrarUnaFactura(factura);
    }
}
