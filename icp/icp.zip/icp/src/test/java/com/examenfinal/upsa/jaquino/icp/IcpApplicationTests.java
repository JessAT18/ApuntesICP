package com.examenfinal.upsa.jaquino.icp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcpApplicationTests {

	@Test
	void contextLoads() {
	}

}
