INSERT INTO productos (nombre_producto, stock) VALUES ('Computadora S1', 1000);
INSERT INTO productos (nombre_producto, stock) VALUES ('Computadora S2', 2000);
INSERT INTO sucursales (nombre, nro_traspasos) VALUES ('Aquino Torrez', 0);