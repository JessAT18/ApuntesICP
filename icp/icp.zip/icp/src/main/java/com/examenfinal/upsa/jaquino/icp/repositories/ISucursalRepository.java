package com.examenfinal.upsa.jaquino.icp.repositories;

import com.examenfinal.upsa.jaquino.icp.entities.Sucursal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ISucursalRepository extends JpaRepository<Sucursal, Integer> {
}
