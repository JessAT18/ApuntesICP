package com.examenfinal.upsa.jaquino.icp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcpApplication {

	public static void main(String[] args) {
		SpringApplication.run(IcpApplication.class, args);
	}

}
