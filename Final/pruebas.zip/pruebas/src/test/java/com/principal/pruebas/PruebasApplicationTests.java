package com.principal.pruebas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebasApplicationTests {

	@Test
	void contextLoads() {
	}

}
