insert into vetbl_facturas values(1,"TABLET",300);
insert into vetbl_facturas values(2,"DISCO DURO",600);
